-- ============================================================================
--  NORDIA DISTRIBUTION - Création du schéma de la base de données
--  Sujet 1 : SQL / PostgreSQL - Contrôle de gestion commercial
--  À exécuter EN PREMIER, avant 02_import_donnees.sql
-- ============================================================================

-- Étape 0 : créer la base depuis psql ou pgAdmin  (à exécuter une seule fois)
--   CREATE DATABASE nordia WITH ENCODING 'UTF8';
-- puis se connecter à la base :  \c nordia

-- Nettoyage si l'on relance le script -----------------------------------------
DROP TABLE IF EXISTS reglements CASCADE;
DROP TABLE IF EXISTS factures CASCADE;
DROP TABLE IF EXISTS lignes_commande CASCADE;
DROP TABLE IF EXISTS commandes CASCADE;
DROP TABLE IF EXISTS budget_commercial CASCADE;
DROP TABLE IF EXISTS produits CASCADE;
DROP TABLE IF EXISTS fournisseurs CASCADE;
DROP TABLE IF EXISTS clients CASCADE;
DROP TABLE IF EXISTS commerciaux CASCADE;
DROP TABLE IF EXISTS entrepots CASCADE;

-- ----------------------------------------------------------------- Référentiels
CREATE TABLE fournisseurs (
    fournisseur_id         INTEGER PRIMARY KEY,
    nom_fournisseur        VARCHAR(80)  NOT NULL,
    pays                   VARCHAR(40)  NOT NULL,
    delai_livraison_jours  INTEGER      NOT NULL,
    categorie_achat        CHAR(1)      NOT NULL      -- A / B / C
);

CREATE TABLE produits (
    produit_id               INTEGER PRIMARY KEY,
    reference                VARCHAR(30)  NOT NULL UNIQUE,
    libelle_produit          VARCHAR(120) NOT NULL,
    famille                  VARCHAR(60)  NOT NULL,
    sous_famille             VARCHAR(60)  NOT NULL,
    prix_achat_ht            NUMERIC(12,2) NOT NULL,   -- coût d'achat = base du calcul de marge
    prix_vente_catalogue_ht  NUMERIC(12,2) NOT NULL,
    fournisseur_id           INTEGER REFERENCES fournisseurs(fournisseur_id),
    actif                    BOOLEAN      NOT NULL
);

CREATE TABLE entrepots (
    entrepot_id          INTEGER PRIMARY KEY,
    libelle_entrepot     VARCHAR(60) NOT NULL,
    ville                VARCHAR(50) NOT NULL,
    region               VARCHAR(60) NOT NULL,
    surface_m2           INTEGER     NOT NULL,
    cout_fixe_mensuel    NUMERIC(12,2) NOT NULL
);

CREATE TABLE commerciaux (
    commercial_id        INTEGER PRIMARY KEY,
    nom                  VARCHAR(50) NOT NULL,
    prenom               VARCHAR(50) NOT NULL,
    region               VARCHAR(60) NOT NULL,
    date_embauche        DATE        NOT NULL,
    salaire_fixe_annuel  NUMERIC(12,2) NOT NULL,
    taux_commission      NUMERIC(6,4)  NOT NULL       -- ex. 0.0180 = 1,80 % du CA
);

CREATE TABLE clients (
    client_id                INTEGER PRIMARY KEY,
    raison_sociale           VARCHAR(120) NOT NULL,
    segment                  VARCHAR(30)  NOT NULL,   -- Grands comptes / PME / Artisan / Collectivité
    region                   VARCHAR(60)  NOT NULL,
    ville                    VARCHAR(50)  NOT NULL,
    code_postal              VARCHAR(10)  NOT NULL,
    date_creation            DATE         NOT NULL,
    encours_autorise         NUMERIC(12,2) NOT NULL,
    delai_paiement_jours     INTEGER      NOT NULL,
    actif                    BOOLEAN      NOT NULL
);

-- --------------------------------------------------------------- Flux de vente
CREATE TABLE commandes (
    commande_id     INTEGER PRIMARY KEY,
    client_id       INTEGER NOT NULL REFERENCES clients(client_id),
    commercial_id   INTEGER NOT NULL REFERENCES commerciaux(commercial_id),
    entrepot_id     INTEGER NOT NULL REFERENCES entrepots(entrepot_id),
    date_commande   DATE    NOT NULL,
    canal_vente     VARCHAR(20) NOT NULL,             -- Agence / Web / Téléphone / EDI
    statut          VARCHAR(20) NOT NULL              -- Livrée / En cours / Annulée
);

CREATE TABLE lignes_commande (
    ligne_id          INTEGER PRIMARY KEY,
    commande_id       INTEGER NOT NULL REFERENCES commandes(commande_id),
    produit_id        INTEGER NOT NULL REFERENCES produits(produit_id),
    quantite          INTEGER NOT NULL,
    prix_unitaire_ht  NUMERIC(12,2) NOT NULL,         -- prix réellement négocié, avant remise
    taux_remise       NUMERIC(6,4)  NOT NULL          -- ex. 0.1200 = 12 %
);

CREATE TABLE factures (
    facture_id     INTEGER PRIMARY KEY,
    commande_id    INTEGER NOT NULL REFERENCES commandes(commande_id),
    client_id      INTEGER NOT NULL REFERENCES clients(client_id),
    date_facture   DATE NOT NULL,
    date_echeance  DATE NOT NULL,
    montant_ht     NUMERIC(14,2) NOT NULL,
    montant_ttc    NUMERIC(14,2) NOT NULL
);

CREATE TABLE reglements (
    reglement_id     INTEGER PRIMARY KEY,
    facture_id       INTEGER NOT NULL REFERENCES factures(facture_id),
    date_reglement   DATE NOT NULL,
    montant_regle    NUMERIC(14,2) NOT NULL,
    mode_reglement   VARCHAR(20) NOT NULL
);

-- ------------------------------------------------------------------- Budget
CREATE TABLE budget_commercial (
    annee            INTEGER NOT NULL,
    mois             INTEGER NOT NULL,
    region           VARCHAR(60) NOT NULL,
    famille_produit  VARCHAR(60) NOT NULL,
    ca_budget_ht     NUMERIC(14,2) NOT NULL,
    marge_budget_ht  NUMERIC(14,2) NOT NULL,
    PRIMARY KEY (annee, mois, region, famille_produit)
);

-- ------------------------------------------------------------------- Index
CREATE INDEX idx_cde_date    ON commandes(date_commande);
CREATE INDEX idx_cde_client  ON commandes(client_id);
CREATE INDEX idx_lig_cde     ON lignes_commande(commande_id);
CREATE INDEX idx_lig_prod    ON lignes_commande(produit_id);
CREATE INDEX idx_fac_client  ON factures(client_id);
CREATE INDEX idx_reg_facture ON reglements(facture_id);

-- Fin du script. Passer à 02_import_donnees.sql
