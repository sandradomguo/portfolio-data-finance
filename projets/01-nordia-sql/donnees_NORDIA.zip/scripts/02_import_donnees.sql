-- ============================================================================
--  NORDIA DISTRIBUTION - Import des données depuis les fichiers CSV
--  À exécuter APRÈS 01_creation_base.sql
--
--  IMPORTANT : la commande \copy (avec un antislash) est une commande PSQL,
--  exécutée depuis VOTRE poste. Elle lit donc les fichiers sur votre disque.
--  ==> Remplacez le chemin ci-dessous par le vôtre, puis exécutez le script
--      dans psql :   \i 02_import_donnees.sql
--
--  Windows  : 'C:/Users/VotreNom/Documents/NORDIA/CSV/clients.csv'
--             (utilisez des slash / même sous Windows)
--  macOS    : '/Users/votrenom/Documents/NORDIA/CSV/clients.csv'
--
--  Les CSV sont encodés en UTF-8 et séparés par un point-virgule ( ; ).
-- ============================================================================

-- Définit une fois pour toutes le dossier des CSV (psql v10+)
\set chemin 'C:/NORDIA/CSV'

\copy fournisseurs       FROM 'C:/NORDIA/CSV/fournisseurs.csv'       WITH (FORMAT csv, HEADER true, DELIMITER ';', ENCODING 'UTF8');
\copy entrepots          FROM 'C:/NORDIA/CSV/entrepots.csv'          WITH (FORMAT csv, HEADER true, DELIMITER ';', ENCODING 'UTF8');
\copy commerciaux        FROM 'C:/NORDIA/CSV/commerciaux.csv'        WITH (FORMAT csv, HEADER true, DELIMITER ';', ENCODING 'UTF8');
\copy clients            FROM 'C:/NORDIA/CSV/clients.csv'            WITH (FORMAT csv, HEADER true, DELIMITER ';', ENCODING 'UTF8');
\copy produits           FROM 'C:/NORDIA/CSV/produits.csv'           WITH (FORMAT csv, HEADER true, DELIMITER ';', ENCODING 'UTF8');
\copy commandes          FROM 'C:/NORDIA/CSV/commandes.csv'          WITH (FORMAT csv, HEADER true, DELIMITER ';', ENCODING 'UTF8');
\copy lignes_commande    FROM 'C:/NORDIA/CSV/lignes_commande.csv'    WITH (FORMAT csv, HEADER true, DELIMITER ';', ENCODING 'UTF8');
\copy factures           FROM 'C:/NORDIA/CSV/factures.csv'           WITH (FORMAT csv, HEADER true, DELIMITER ';', ENCODING 'UTF8');
\copy reglements         FROM 'C:/NORDIA/CSV/reglements.csv'         WITH (FORMAT csv, HEADER true, DELIMITER ';', ENCODING 'UTF8');
\copy budget_commercial  FROM 'C:/NORDIA/CSV/budget_commercial.csv'  WITH (FORMAT csv, HEADER true, DELIMITER ';', ENCODING 'UTF8');

-- ------------------------------------------------------------------ Contrôle
-- Les compteurs attendus sont indiqués en commentaire : si un chiffre diffère,
-- l'import a échoué pour la table concernée.
SELECT 'fournisseurs'      AS table_, COUNT(*) AS lignes, 8     AS attendu FROM fournisseurs
UNION ALL SELECT 'entrepots',         COUNT(*), 5      FROM entrepots
UNION ALL SELECT 'commerciaux',       COUNT(*), 18     FROM commerciaux
UNION ALL SELECT 'clients',           COUNT(*), 420    FROM clients
UNION ALL SELECT 'produits',          COUNT(*), 180    FROM produits
UNION ALL SELECT 'commandes',         COUNT(*), 7867   FROM commandes
UNION ALL SELECT 'lignes_commande',   COUNT(*), 27436  FROM lignes_commande
UNION ALL SELECT 'factures',          COUNT(*), 7082   FROM factures
UNION ALL SELECT 'reglements',        COUNT(*), 6847   FROM reglements
UNION ALL SELECT 'budget_commercial', COUNT(*), 864    FROM budget_commercial;

-- ------------------------------------------------- Vue de travail conseillée
-- Cette vue calcule le CA net et la marge brute ligne à ligne : elle vous
-- fera gagner beaucoup de temps sur les parties 3 à 6.
CREATE OR REPLACE VIEW v_ventes AS
SELECT  l.ligne_id,
        c.commande_id,
        c.date_commande,
        EXTRACT(YEAR  FROM c.date_commande)::int AS annee,
        EXTRACT(MONTH FROM c.date_commande)::int AS mois,
        c.canal_vente,
        c.statut,
        cl.client_id, cl.raison_sociale, cl.segment, cl.region,
        co.commercial_id, co.nom AS nom_commercial, co.prenom AS prenom_commercial,
        p.produit_id, p.reference, p.libelle_produit, p.famille, p.sous_famille,
        l.quantite,
        l.prix_unitaire_ht,
        l.taux_remise,
        ROUND(l.quantite * l.prix_unitaire_ht * (1 - l.taux_remise), 2)                       AS ca_net_ht,
        ROUND(l.quantite * p.prix_achat_ht, 2)                                                AS cout_achat_ht,
        ROUND(l.quantite * (l.prix_unitaire_ht * (1 - l.taux_remise) - p.prix_achat_ht), 2)   AS marge_brute_ht
FROM        lignes_commande l
JOIN        commandes  c  ON c.commande_id  = l.commande_id
JOIN        clients    cl ON cl.client_id   = c.client_id
JOIN        commerciaux co ON co.commercial_id = c.commercial_id
JOIN        produits   p  ON p.produit_id   = l.produit_id;
